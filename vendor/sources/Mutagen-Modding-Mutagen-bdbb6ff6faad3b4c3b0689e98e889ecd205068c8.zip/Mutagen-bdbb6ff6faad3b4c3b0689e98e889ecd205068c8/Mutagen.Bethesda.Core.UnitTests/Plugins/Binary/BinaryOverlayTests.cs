using Mutagen.Bethesda.Plugins;
using Mutagen.Bethesda.Plugins.Binary.Overlay;
using Mutagen.Bethesda.Plugins.Binary.Streams;
using Mutagen.Bethesda.Plugins.Binary.Translations;
using Mutagen.Bethesda.Plugins.Internals;
using Mutagen.Bethesda.Plugins.Meta;
using Mutagen.Bethesda.Plugins.Records.Internals;
using Mutagen.Bethesda.Testing.AutoData;
using Noggog;
using Xunit;

namespace Mutagen.Bethesda.UnitTests.Plugins.Binary;

public class BinaryOverlayTests
{
    #region ParseRecordLocationsByCount Collection Trigger
    [Theory, MutagenAutoData]
    public void ParseRecordLocationsByCount_Single_EndOfStream(ModKey modKey)
    {
        MemoryTributary data = new MemoryTributary();
        using (MutagenWriter writer = new MutagenWriter(data, GameConstants.Oblivion))
        {
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(0);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(2);
            }
        }

        data.Position = 0;
        var triggers = new RecordTriggerSpecs(RecordCollection.Factory(RecordTypes.EDID));
        var stream = new OverlayStream(data.ToArray(), new ParsingMeta(GameConstants.Oblivion, modKey, masterReferences: null!));
        var pos = PluginBinaryOverlay.ParseRecordLocationsByCount(
            stream,
            3,
            triggers,
            GameConstants.Oblivion.SubConstants,
            skipHeader: false);
        Assert.Equal(3, pos.Count);
        Assert.Equal(0, pos[0]);
        Assert.Equal(10, pos[1]);
        Assert.Equal(20, pos[2]);
        Assert.Equal(30, stream.Position);
        Assert.True(stream.Complete);
    }

    [Theory, MutagenAutoData]
    public void ParseRecordLocationsByCount_Single_MoreRecords(ModKey modKey)
    {
        MemoryTributary data = new MemoryTributary();
        using (MutagenWriter writer = new MutagenWriter(data, GameConstants.Oblivion))
        {
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(0);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.MAST))
            {
                writer.Write(2);
            }
        }

        data.Position = 0;
        var triggers = new RecordTriggerSpecs(RecordCollection.Factory(RecordTypes.EDID));
        var stream = new OverlayStream(data.ToArray(), new ParsingMeta(GameConstants.Oblivion, modKey, masterReferences: null!));
        var pos = PluginBinaryOverlay.ParseRecordLocationsByCount(
            stream,
            3,
            triggers,
            GameConstants.Oblivion.SubConstants,
            skipHeader: false);
        Assert.Equal(3, pos.Count);
        Assert.Equal(0, pos[0]);
        Assert.Equal(10, pos[1]);
        Assert.Equal(20, pos[2]);
        Assert.Equal(30, stream.Position);
        Assert.False(stream.Complete);
    }

    [Theory, MutagenAutoData]
    public void ParseRecordLocationsByCount_Alternating_EndOfStream(ModKey modKey)
    {
        MemoryTributary data = new MemoryTributary();
        using (MutagenWriter writer = new MutagenWriter(data, GameConstants.Oblivion))
        {
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DATA))
            {
                writer.Write(-1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DATA))
            {
                writer.Write(-2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(3);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DATA))
            {
                writer.Write(-3);
            }
        }

        data.Position = 0;
        var triggers = new RecordTriggerSpecs(RecordCollection.Factory(RecordTypes.EDID, RecordTypes.DATA));
        var stream = new OverlayStream(data.ToArray(), new ParsingMeta(GameConstants.Oblivion, modKey, masterReferences: null!));
        var pos = PluginBinaryOverlay.ParseRecordLocationsByCount(
            stream,
            3,
            triggers,
            GameConstants.Oblivion.SubConstants,
            skipHeader: false);
        Assert.Equal(3, pos.Count);
        Assert.Equal(0, pos[0]);
        Assert.Equal(20, pos[1]);
        Assert.Equal(40, pos[2]);
        Assert.Equal(60, stream.Position);
        Assert.True(stream.Complete);
    }

    [Theory, MutagenAutoData]
    public void ParseRecordLocationsByCount_Alternating_MoreData(ModKey modKey)
    {
        MemoryTributary data = new MemoryTributary();
        using (MutagenWriter writer = new MutagenWriter(data, GameConstants.Oblivion))
        {
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DATA))
            {
                writer.Write(-1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DATA))
            {
                writer.Write(-2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.EDID))
            {
                writer.Write(3);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DATA))
            {
                writer.Write(-3);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.MAST))
            {
                writer.Write(-3);
            }
        }

        data.Position = 0;
        var triggers = new RecordTriggerSpecs(RecordCollection.Factory(RecordTypes.EDID, RecordTypes.DATA));
        var stream = new OverlayStream(data.ToArray(), new ParsingMeta(GameConstants.Oblivion, modKey, masterReferences: null!));
        var pos = PluginBinaryOverlay.ParseRecordLocationsByCount(
            stream,
            3,
            triggers,
            GameConstants.Oblivion.SubConstants,
            skipHeader: false);
        Assert.Equal(3, pos.Count);
        Assert.Equal(0, pos[0]);
        Assert.Equal(20, pos[1]);
        Assert.Equal(40, pos[2]);
        Assert.Equal(60, stream.Position);
        Assert.False(stream.Complete);
    }

    [Theory, MutagenAutoData]
    public void ParseRecordLocationsByCount_EndRecord(ModKey modKey)
    {
        MemoryTributary data = new MemoryTributary();
        using (MutagenWriter writer = new MutagenWriter(data, GameConstants.Oblivion))
        {
            using (HeaderExport.Subrecord(writer, RecordTypes.ATAN))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DESC))
            {
                writer.Write(-1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.ATAF))
            {
                writer.Write(2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.ATAN))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DESC))
            {
                writer.Write(-2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.ATAF))
            {
                writer.Write(2);
            }
        }

        data.Position = 0;
        var triggers = new RecordTriggerSpecs(
            allRecordTypes: RecordCollection.Factory(
                RecordTypes.ATAN,
                RecordTypes.ATAF,
                RecordTypes.DESC),
            triggeringRecordTypes: RecordCollection.Factory(RecordTypes.ATAN),
            endRecordTypes: RecordCollection.Factory(RecordTypes.ATAF));
        
        var stream = new OverlayStream(data.ToArray(), new ParsingMeta(GameConstants.Oblivion, modKey, masterReferences: null!));
        var pos = PluginBinaryOverlay.ParseRecordLocationsByCount(
            stream,
            3,
            triggers,
            GameConstants.Oblivion.SubConstants,
            skipHeader: false);
        Assert.Equal(2, pos.Count);
        Assert.Equal(0, pos[0]);
        Assert.Equal(30, pos[1]);
        Assert.Equal(60, stream.Position);
        Assert.True(stream.Complete);
    }

    [Theory, MutagenAutoData]
    public void ParseRecordLocationsByCount_EndRecordWithUnrelatedMatchingAfter(ModKey modKey)
    {
        MemoryTributary data = new MemoryTributary();
        using (MutagenWriter writer = new MutagenWriter(data, GameConstants.Oblivion))
        {
            using (HeaderExport.Subrecord(writer, RecordTypes.ATAN))
            {
                writer.Write(1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DESC))
            {
                writer.Write(-1);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.ATAF))
            {
                writer.Write(2);
            }
            using (HeaderExport.Subrecord(writer, RecordTypes.DESC))
            {
                writer.Write(-2);
            }
        }

        data.Position = 0;
        var triggers = new RecordTriggerSpecs(
            allRecordTypes: RecordCollection.Factory(
                RecordTypes.ATAN,
                RecordTypes.ATAF,
                RecordTypes.DESC),
            triggeringRecordTypes: RecordCollection.Factory(RecordTypes.ATAN),
            endRecordTypes: RecordCollection.Factory(RecordTypes.ATAF));
        
        var stream = new OverlayStream(data.ToArray(), new ParsingMeta(GameConstants.Oblivion, modKey, masterReferences: null!));
        var pos = PluginBinaryOverlay.ParseRecordLocationsByCount(
            stream,
            3,
            triggers,
            GameConstants.Oblivion.SubConstants,
            skipHeader: false);
        Assert.Equal(1, pos.Count);
        Assert.Equal(0, pos[0]);
        Assert.Equal(30, stream.Position);
        Assert.False(stream.Complete);
    }
    #endregion
}