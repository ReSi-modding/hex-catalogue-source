using Noggog;
using System.Diagnostics.CodeAnalysis;

namespace Loqui;

public static class EqualsMaskHelper
{
    public enum Include
    {
        All,
        OnlyFailures,
    }

    public static void EqualsHelper<T, M>(
        MaskItem<bool, M?> maskItem,
        T lhs,
        T rhs,
        Func<T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        if (lhs == null && rhs == null)
        {
            maskItem.Overall = true;
            maskItem.Specific = default;
        }
        else if (lhs == null || rhs == null)
        {
            maskItem.Overall = false;
            maskItem.Specific = default;
        }
        var mask = maskGetter(lhs, rhs);
        maskItem.Overall = mask.All((b) => b);
        if (!maskItem.Overall || include == Include.All)
        {
            maskItem.Specific = mask;
        }
    }

    public static void EqualsHelper<K, T, M>(
        MaskItemIndexed<K, bool, M?> maskItem,
        T lhs,
        T rhs,
        Func<K, T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        if (lhs == null && rhs == null)
        {
            maskItem.Overall = true;
            maskItem.Specific = default;
        }
        else if (lhs == null || rhs == null)
        {
            maskItem.Overall = false;
            maskItem.Specific = default;
        }
        var mask = maskGetter(maskItem.Index, lhs, rhs);
        maskItem.Overall = mask.All((b) => b);
        if (!maskItem.Overall || include == Include.All)
        {
            maskItem.Specific = mask;
        }
    }

    public static MaskItem<bool, M?>? EqualsHelper<T, M>(
        T? lhs,
        T? rhs,
        Func<T, T, Include, M> maskGetter,
        Include include)
        where T : class
        where M : class, IMask<bool>
    {
        if (lhs == null && rhs == null)
        {
            return include == Include.All ? new MaskItem<bool, M?>(true, default) : null;
        }
        else if (lhs == null || rhs == null)
        {
            return new MaskItem<bool, M?>(false, default);
        }
        var mask = maskGetter(lhs, rhs, include);
        var overall = mask.All((b) => b);
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, M?>(overall, mask);
        }
        return null;
    }

    public static bool RefEquality<T>([NotNullWhen(true)] T? lhs, [NotNullWhen(true)] T? rhs, out bool isEqual)
        where T : class
    {
        if (lhs == null && rhs == null)
        {
            isEqual = true;
            return false;
        }
        if (lhs == null || rhs == null)
        {
            isEqual = false;
            return false;
        }
        if (ReferenceEquals(lhs, rhs))
        {
            isEqual = true;
            return false;
        }

        isEqual = false;
        return true;
    }

    public static bool RefEquality<T>(T? lhs, T? rhs, [MaybeNullWhen(false)] out T lhsOut, [MaybeNullWhen(false)] out T rhsOut, out bool isEqual)
        where T : class
    {
        if (lhs == null && rhs == null)
        {
            isEqual = true;
            lhsOut = default;
            rhsOut = default;
            return false;
        }
        if (lhs == null || rhs == null)
        {
            isEqual = false;
            lhsOut = default;
            rhsOut = default;
            return false;
        }
        if (ReferenceEquals(lhs, rhs))
        {
            isEqual = true;
            lhsOut = default;
            rhsOut = default;
            return false;
        }

        lhsOut = lhs;
        rhsOut = rhs;
        isEqual = false;
        return true;
    }

    #region Enumerable
    public static MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>? CollectionEqualsHelper<T, M>(
        this IEnumerable<T>? lhs,
        IEnumerable<T>? rhs,
        Func<T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        if (lhs == null && rhs == null)
        {
            return include == Include.All ? new MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>(true, default) : default;
        }
        if (lhs == null || rhs == null)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>(false, default);
        }
        int index = 0;
        var masks = lhs.SelectAgainst<T, MaskItemIndexed<bool, M?>>(
                rhs,
                (l, r) =>
                {
                    var itemRet = new MaskItemIndexed<bool, M?>(index++, false, default);
                    EqualsHelper(itemRet, l, r, maskGetter, include);
                    return itemRet;
                },
                out var countEqual)
            .Where(i => include == Include.All || !i.Overall)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Overall);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<(int Index, bool EqualValues)>?>? CollectionEqualsHelper<T>(
        this IEnumerable<T>? lhs,
        IEnumerable<T>? rhs,
        Func<T, T, bool> maskGetter,
        Include include)
    {
        if (lhs == null && rhs == null)
        {
            return include == Include.All ? new MaskItem<bool, IEnumerable<(int Index, bool EqualValues)>?>(true, default) : default;
        }
        if (lhs == null || rhs == null)
        {
            return new MaskItem<bool, IEnumerable<(int Index, bool EqualValues)>?>(false, default);
        }
        int index = 0;
        var masks = lhs.SelectAgainst<T, (int Index, bool EqualValues)>(
                rhs,
                (l, r) =>
                {
                    return (index++, maskGetter(l, r));
                }, out var countEqual)
            .Where(i => include == Include.All || !i.EqualValues)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.EqualValues);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<(int, bool)>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<MaskItemIndexed<P2Int, bool, M?>>?>? Array2dEqualsHelper<T, M>(
        this IReadOnlyArray2d<T>? lhs,
        IReadOnlyArray2d<T>? rhs,
        Func<T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        if (lhs == null && rhs == null)
        {
            return include == Include.All ? new MaskItem<bool, IEnumerable<MaskItemIndexed<P2Int, bool, M?>>?>(true, default) : default;
        }
        if (lhs == null || rhs == null)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<P2Int, bool, M?>>?>(false, default);
        }

        if (lhs.Width != rhs.Width
            || lhs.Height != rhs.Height)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<P2Int, bool, M?>>?>(false, default);
        }
        
        var overall = true;
        List<MaskItemIndexed<P2Int, bool, M?>> masks = new();
        for (int y = 0; y < lhs.Height; y++)
        {
            for (int x = 0; x < lhs.Width; x++)
            {
                var lhsVal = lhs[x, y];
                var rhsVal = rhs[x, y];
                var val = new MaskItemIndexed<P2Int, bool, M?>(index:new P2Int(x, y), overall: false, specific: default);
                EqualsHelper(val, lhsVal, rhsVal, maskGetter, include);
                
                if (include == Include.All || !val.Overall)
                {
                    masks.Add(val);
                }
                else
                {
                    overall = false;
                }
            }
        }
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Overall);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<P2Int, bool, M?>>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<(P2Int Index, bool EqualValues)>?>? Array2dEqualsHelper<T>(
        this IReadOnlyArray2d<T>? lhs,
        IReadOnlyArray2d<T>? rhs,
        Func<T, T, bool> maskGetter,
        Include include)
    {
        if (lhs == null && rhs == null)
        {
            return include == Include.All ? new MaskItem<bool, IEnumerable<(P2Int Index, bool EqualValues)>?>(true, default) : default;
        }
        if (lhs == null || rhs == null)
        {
            return new MaskItem<bool, IEnumerable<(P2Int Index, bool EqualValues)>?>(false, default);
        }

        if (lhs.Width != rhs.Width
            || lhs.Height != rhs.Height)
        {
            return new MaskItem<bool, IEnumerable<(P2Int Index, bool EqualValues)>?>(false, default);
        }
        
        var overall = true;
        List<(P2Int Index, bool EqualValues) > masks = new();
        for (int y = 0; y < lhs.Height; y++)
        {
            for (int x = 0; x < lhs.Width; x++)
            {
                var lhsVal = lhs[x, y];
                var rhsVal = rhs[x, y];
                var val = (Index: new P2Int(x, y), EqualValues: maskGetter(lhsVal, rhsVal));
                if (include == Include.All || !val.EqualValues)
                {
                    masks.Add(val);
                }
                else
                {
                    overall = false;
                }
            }
        }
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.EqualValues);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<(P2Int, bool)>?>(overall, masks);
        }
        return null;
    }
    #endregion

    #region List
    public static MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>? CollectionEqualsHelper<T, M>(
        this IReadOnlyList<T>? lhs,
        IReadOnlyList<T>? rhs,
        Func<T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        return CollectionEqualsHelper(lhs as IEnumerable<T>, rhs as IEnumerable<T>, maskGetter, include);
    }

    public static MaskItem<bool, IEnumerable<(int Index, bool EqualValues)>?>? CollectionEqualsHelper<T>(
        this IReadOnlyList<T>? lhs,
        IReadOnlyList<T>? rhs,
        Func<T, T, bool> maskGetter,
        Include include)
    {
        return CollectionEqualsHelper(lhs as IEnumerable<T>, rhs as IEnumerable<T>, maskGetter, include);
    }
    #endregion

    #region Span
    public static MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>? SpanEqualsHelper<T, M>(
        this ReadOnlyMemorySlice<T>? lhs,
        ReadOnlyMemorySlice<T>? rhs,
        Func<T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        return CollectionEqualsHelper(lhs, rhs, maskGetter, include);
    }

    public static MaskItem<bool, IEnumerable<(int Index, bool EqualValues)>?>? SpanEqualsHelper<T>(
        this ReadOnlyMemorySlice<T>? lhs,
        ReadOnlyMemorySlice<T>? rhs,
        Func<T, T, bool> maskGetter,
        Include include)
    {
        return CollectionEqualsHelper(lhs, rhs, maskGetter, include);
    }

    public static MaskItem<bool, IEnumerable<MaskItemIndexed<bool, M?>>?>? SpanEqualsHelper<T, M>(
        this ReadOnlyMemorySlice<T> lhs,
        ReadOnlyMemorySlice<T> rhs,
        Func<T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        return CollectionEqualsHelper(lhs, rhs, maskGetter, include);
    }

    public static MaskItem<bool, IEnumerable<(int Index, bool EqualValues)>?>? SpanEqualsHelper<T>(
        this ReadOnlyMemorySlice<T> lhs,
        ReadOnlyMemorySlice<T> rhs,
        Func<T, T, bool> maskGetter,
        Include include)
    {
        return CollectionEqualsHelper(lhs, rhs, maskGetter, include);
    }
    #endregion

    #region Dict
    public static MaskItem<bool, IEnumerable<MaskItemIndexed<K, bool, M?>>?>? DictEqualsHelper<K, T, M>(
        this IReadOnlyDictionary<K, T> lhs,
        IReadOnlyDictionary<K, T> rhs,
        Func<K, T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        var masks = lhs.SelectAgainst<K, T, MaskItemIndexed<K, bool, M?>>(
                rhs,
                (k, l, r) =>
                {
                    var itemRet = new MaskItemIndexed<K, bool, M?>(k, false, default);
                    EqualsHelper(itemRet, l, r, maskGetter, include);
                    return itemRet;
                },
                out var countEqual)
            .Select(kv => kv.Value)
            .Where(i => include == Include.All || !i.Overall)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Overall);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<K, bool, M?>>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<KeyValuePair<K, bool>>?>? DictEqualsHelper<K, T>(
        this IReadOnlyDictionary<K, T> lhs,
        IReadOnlyDictionary<K, T> rhs,
        Func<K, T, T, bool> maskGetter,
        Include include)
    {
        var masks = lhs.SelectAgainst<K, T, bool>(
                rhs,
                (k, l, r) =>
                {
                    return maskGetter(k, l, r);
                },
                out var countEqual)
            .Where(i => include == Include.All || !i.Value)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Value);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<KeyValuePair<K, bool>>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<KeyValuePair<K, bool>>?>? DictEqualsHelper<K, T>(
        this IReadOnlyDictionary<K, T> lhs,
        IReadOnlyDictionary<K, T> rhs,
        Include include)
    {
        var masks = lhs.SelectAgainst<K, T, bool>(
                rhs,
                (k, l, r) =>
                {
                    return EqualityComparer<T>.Default.Equals(l, r);
                },
                out var countEqual)
            .Where(i => include == Include.All || !i.Value)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Value);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<KeyValuePair<K, bool>>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<MaskItemIndexed<K, bool, M?>>?>? CacheEqualsHelper<K, T, M>(
        this IReadOnlyCache<T, K> lhs,
        IReadOnlyCache<T, K> rhs,
        Func<K, T, T, M> maskGetter,
        Include include)
        where M : class, IMask<bool>
    {
        var masks = lhs.SelectAgainst<K, T, MaskItemIndexed<K, bool, M?>>(
                rhs,
                (k, l, r) =>
                {
                    var itemRet = new MaskItemIndexed<K, bool, M?>(k, false, default);
                    EqualsHelper(itemRet, l, r, maskGetter, include);
                    return itemRet;
                },
                out var countEqual)
            .Select(kv => kv.Value)
            .Where(i => include == Include.All || !i.Overall)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Overall);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<MaskItemIndexed<K, bool, M?>>?>(overall, masks);
        }
        return null;
    }

    public static MaskItem<bool, IEnumerable<KeyValuePair<K, bool>>>? CacheEqualsHelper<K, T>(
        this IReadOnlyCache<T, K> lhs,
        IReadOnlyCache<T, K> rhs,
        Func<K, T, T, bool> maskGetter,
        Include include)
    {
        var masks = lhs.SelectAgainst<K, T, bool>(
                rhs,
                (k, l, r) =>
                {
                    return maskGetter(k, l, r);
                },
                out var countEqual)
            .Where(i => include == Include.All || !i.Value)
            .ToArray();
        var overall = countEqual;
        if (overall)
        {
            switch (include)
            {
                case Include.All:
                    overall = masks.All((b) => b.Value);
                    break;
                case Include.OnlyFailures:
                    overall = !masks.Any();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }
        if (!overall || include == Include.All)
        {
            return new MaskItem<bool, IEnumerable<KeyValuePair<K, bool>>>(overall, masks);
        }
        return null;
    }
    #endregion
}