using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using JetBrains.Annotations;

namespace NexusMods.Paths;

/// <summary>
/// Enum of known directory and file paths. This should be
/// used instead of <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>.
/// </summary>
[PublicAPI]
public enum KnownPath
{
    /// <summary>
    /// The path of the base directory that the assembly
    /// resolver uses to probe for assemblies.
    /// </summary>
    /// <remarks>
    /// This is often the same as <see cref="CurrentDirectory"/>.
    /// <see cref="BaseFileSystem"/> uses <see cref="AppContext.BaseDirectory"/>
    /// to get this value.
    /// </remarks>
    EntryDirectory,

    /// <summary>
    /// The current working directory.
    /// </summary>
    /// <remarks>
    /// This is often the same as <see cref="EntryDirectory"/>.
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.CurrentDirectory"/>
    /// to get this value.
    /// </remarks>
    CurrentDirectory,

    /// <summary>
    /// The directory that serves as a common repository for application-specific
    /// data that is used by all users.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_COMMON_APPDATA) ProgramData folder <c>%ALLUSERSPROFILE%</c>
    ///             (<c>%ProgramData%"</c>, <c>%SystemDrive%/ProgramData</c>)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description><c>/usr/share</c></description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.CommonApplicationData"/> to get this value.
    /// </remarks>
    CommonApplicationDataDirectory,

    /// <summary>
    /// The program files directory.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_PROGRAM_FILES) Program Files folder for the current process architecture
    ///             <c>%ProgramFiles%</c> (<c>%SystemDrive%/Program Files</c>)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description>This folder doesn't exist on Linux!</description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.ProgramFiles"/> to get this value.
    /// </remarks>
    ProgramFilesDirectory,

    /// <summary>
    /// The 32 bit Program Files directory.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_PROGRAM_FILESX86) 32 bit Program Files folder (available to both 32/64 bit processes)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description>This folder doesn't exist on Linux!</description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.ProgramFilesX86"/> to get this value.
    /// </remarks>
    ProgramFilesX86Directory,

    /// <summary>
    /// The directory for components that are shared across applications.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_PROGRAM_FILES_COMMON) Common Program Files folder for the current process architecture
    ///             <c>%ProgramFiles%/Common Files</c>
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description>This folder doesn't exist on Linux!</description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.CommonProgramFiles"/> to get this value.
    /// </remarks>
    CommonProgramFilesDirectory,

    /// <summary>
    /// The directory for components that are shared across applications.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_PROGRAM_FILES_COMMONX86) Common 32 bit Program Files folder (available to both 32/64 bit processes)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description>This folder doesn't exist on Linux!</description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.CommonProgramFilesX86"/> to get this value.
    /// </remarks>
    CommonProgramFilesX86Directory,

    /// <summary>
    /// The current user's temporary folder. On Linux:
    /// <list type="number">
    ///     <item>The path specified by the <c>TMPDIR</c> environment variable.</item>
    ///     <item>The path <c>/tmp</c>.</item>
    /// </list>
    /// On Windows:
    /// <list type="number">
    ///     <item>The path specified by the <c>TMP</c> environment variable.</item>
    ///     <item>The path specified by the <c>TEMP</c> environment variable.</item>
    ///     <item>The path specified by the <c>USERPROFILE</c> environment variable.</item>
    ///     <item>The Windows directory.</item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Path.GetTempPath"/> to get this value.
    /// </remarks>
    TempDirectory,

    /// <summary>
    /// The user's profile folder.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_PROFILE) The root users profile folder <c>%USERPROFILE%</c>
    ///             (<c>%SystemDrive%/Users/%USERNAME%</c>)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description><c>$HOME</c> or <c>/home/$USER</c></description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.UserProfile"/> to get this value.
    /// </remarks>
    HomeDirectory,

    /// <summary>
    /// The directory that serves as a common repository for application-specific data for the current roaming user. A roaming user works on more than one computer on a network.
    /// A roaming user's profile is kept on a server on the network and is loaded onto a system when the user logs on.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_APPDATA) Roaming user application data folder
    ///             <c>%APPDATA%</c> (<c>%USERPROFILE%/AppData/Roaming</c>)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description><c>XDG_CONFIG_HOME</c> or <c>$HOME/.config</c></description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.ApplicationData"/> to get this value.
    /// </remarks>
    ApplicationDataDirectory,

    /// <summary>
    /// The directory that serves as a common repository for
    /// application-specific data that is used by the current, non-roaming user.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_LOCAL_APPDATA) Local folder
    ///             <c>%LOCALAPPDATA%</c> (<c>%USERPROFILE%/AppData/Local</c>)
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description><c>XDG_DATA_HOME</c> or <c>$HOME/.local/share</c></description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.LocalApplicationData"/> to get this value.
    /// </remarks>
    LocalApplicationDataDirectory,

    /// <summary>
    /// The My Documents folder.
    /// <list type="table">
    ///     <listheader>
    ///         <term>OS</term>
    ///         <description>Path</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Windows</term>
    ///         <description>
    ///             (CSIDL_MYDOCUMENTS, CSIDL_PERSONAL) Documents (My Documents) folder
    ///             <c>%USERPROFILE%/Documents</c>
    ///         </description>
    ///     </item>
    ///     <item>
    ///         <term>Linux</term>
    ///         <description><c>XDG_DOCUMENTS_DIR</c> or <c>$HOME/Documents</c></description>
    ///     </item>
    /// </list>
    /// </summary>
    /// <remarks>
    /// <see cref="BaseFileSystem"/> uses <see cref="Environment.GetFolderPath(System.Environment.SpecialFolder)"/>
    /// with <see cref="Environment.SpecialFolder.MyDocuments"/> to get this value.
    /// </remarks>
    MyDocumentsDirectory,

    /// <summary>
    /// The <c>My Games</c> folder, relative to <see cref="MyDocumentsDirectory"/>.
    /// </summary>
    /// <remarks>
    /// While many games like to use this folder, it is not a special folder
    /// and doesn't have a CSID. <see cref="BaseFileSystem"/> simply combines
    /// <see cref="MyDocumentsDirectory"/> with <c>My Games</c>.
    /// </remarks>
    MyGamesDirectory,

    /// <summary>
    /// <c>$XDG_CONFIG_HOME</c> defines the base directory relative to which user-specific configuration files should be stored.
    /// If <c>$XDG_CONFIG_HOME</c> is either not set or empty, a default equal to <c>$HOME/.config</c> should be used.
    /// </summary>
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    XDG_CONFIG_HOME,

    /// <summary>
    /// <c>$XDG_CACHE_HOME</c> defines the base directory relative to which user-specific non-essential data files should be stored.
    /// If <c>$XDG_CACHE_HOME</c> is either not set or empty, a default equal to <c>$HOME/.cache</c> should be used.
    /// </summary>
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    XDG_CACHE_HOME,

    /// <summary>
    /// <c>$XDG_DATA_HOME</c> defines the base directory relative to which user-specific data files should be stored.
    /// If <c>$XDG_DATA_HOME</c> is either not set or empty, a default equal to <c>$HOME/.local/share</c> should be used.
    /// </summary>
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    XDG_DATA_HOME,

    /// <summary>
    /// <c>$XDG_STATE_HOME</c> defines the base directory relative to which user-specific state files should be stored.
    /// If <c>$XDG_STATE_HOME</c> is either not set or empty, a default equal to <c>$HOME/.local/state</c> should be used.
    /// </summary>
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    XDG_STATE_HOME,

    /// <summary>
    /// <c>$XDG_RUNTIME_DIR</c> defines the base directory relative to which user-specific non-essential runtime files and other file objects (such as sockets, named pipes, ...) should be stored.
    /// The directory MUST be owned by the user, and he MUST be the only one having read and write access to it. Its Unix access mode MUST be 0700.
    /// </summary>
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    XDG_RUNTIME_DIR,
}
