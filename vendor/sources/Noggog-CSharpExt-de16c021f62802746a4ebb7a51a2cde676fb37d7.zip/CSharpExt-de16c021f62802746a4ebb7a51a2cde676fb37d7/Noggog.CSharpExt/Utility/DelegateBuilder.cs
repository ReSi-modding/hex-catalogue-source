using System.Linq.Expressions;
using System.Reflection;

namespace Noggog.Utility;

/*
 * https://stackoverflow.com/questions/13041674/create-func-or-action-for-any-method-using-reflection-in-c
 */
public class DelegateBuilder
{
    public static T BuildDelegate<T>(MethodInfo method, params object[] missingParamValues)
    {
        var queueMissingParams = new Queue<object>(missingParamValues);

        var dgtMi = typeof(T).GetMethod("Invoke")!;
        var dgtRet = dgtMi.ReturnType;
        var dgtParams = dgtMi.GetParameters();

        var paramsOfDelegate = dgtParams
            .Select(tp => Expression.Parameter(tp.ParameterType, tp.Name))
            .ToArray();

        var methodParams = method.GetParameters();

        if (method.IsStatic)
        {
            var paramsToPass = methodParams
                .Select((p, i) => CreateParam(paramsOfDelegate, i, p, queueMissingParams))
                .ToArray();

            var expr = Expression.Lambda<T>(
                Expression.Call(method, paramsToPass),
                paramsOfDelegate);

            return expr.Compile();
        }
        else
        {
            var paramThis = Expression.Convert(paramsOfDelegate[0], method.DeclaringType!);

            var paramsToPass = methodParams
                .Select((p, i) => CreateParam(paramsOfDelegate, i + 1, p, queueMissingParams))
                .ToArray();

            var expr = Expression.Lambda<T>(
                Expression.Call(paramThis, method, paramsToPass),
                paramsOfDelegate);

            return expr.Compile();
        }
    }

    public static RetType BuildGenericDelegate<RetType>(Type containingType, Type[] genTypes, MethodInfo method, params object[] missingParamValues)
    {
        var queueMissingParams = new Queue<object>(missingParamValues);

        var dgtMi = typeof(RetType).GetMethod("Invoke")!;
        var dgtRet = dgtMi.ReturnType;
        var dgtParams = dgtMi.GetParameters();

        var paramsOfDelegate = dgtParams
            .Select(tp => Expression.Parameter(tp.ParameterType, tp.Name))
            .ToArray();

        var methodParams = method.GetParameters();

        if (method.IsStatic)
        {
            var paramsToPass = methodParams
                .Select((p, i) => CreateParam(paramsOfDelegate, i, p, queueMissingParams))
                .ToArray();

            var expr = Expression.Lambda<RetType>(
                Expression.Call(containingType, method.Name, genTypes, paramsToPass),
                paramsOfDelegate);

            return expr.Compile();
        }
        else
        {
            var paramThis = Expression.Convert(paramsOfDelegate[0], method.DeclaringType!);

            var paramsToPass = methodParams
                .Select((p, i) => CreateParam(paramsOfDelegate, i + 1, p, queueMissingParams))
                .ToArray();

            var expr = Expression.Lambda<RetType>(
                Expression.Call(paramThis, method.Name, genTypes, paramsToPass),
                paramsOfDelegate);

            return expr.Compile();
        }
    }

    private static Expression CreateParam(ParameterExpression[] paramsOfDelegate, int i, ParameterInfo callParamType, Queue<object> queueMissingParams)
    {
        if (i < paramsOfDelegate.Length)
            return Expression.Convert(paramsOfDelegate[i], callParamType.ParameterType);

        if (queueMissingParams.Count > 0)
            return Expression.Constant(queueMissingParams.Dequeue());

        if (callParamType.ParameterType.IsValueType)
            return Expression.Constant(Activator.CreateInstance(callParamType.ParameterType));

        return Expression.Constant(null);
    }
}