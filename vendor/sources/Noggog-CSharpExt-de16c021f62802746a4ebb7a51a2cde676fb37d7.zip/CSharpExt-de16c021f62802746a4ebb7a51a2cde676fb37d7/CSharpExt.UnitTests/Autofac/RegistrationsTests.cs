﻿using Autofac;
using Autofac.Core;
using Noggog.Autofac.Validation;
using Noggog.Testing.AutoFixture;
using Noggog.Testing.Extensions;
using NSubstitute;

namespace CSharpExt.UnitTests.Autofac;

public class RegistrationsTests
{
    [Theory, TestData]
    public void NoRegistrationsThrows(
        IContainer container,
        Registrations getRegistrations)
    {
        Assert.Throws<AutofacValidationException>(() =>
        {
            container.ComponentRegistry.Registrations
                .Returns([]);
            getRegistrations.Items.ToArray();
        });
    }

    [Fact]
    public void NormalNeedsValidation()
    {
        var builder = new ContainerBuilder();
        builder.RegisterType<Class>().AsSelf();
        var cont = builder.Build();
        new Registrations(cont).Items
            .Where(x => x.Key == typeof(Class))
            .SelectMany(x => x.Value)
            .ShouldEqualEnumerable(
                new Registration(typeof(Class), true));
    }

    [Fact]
    public void InstanceDoesNotNeedValidation()
    {
        var builder = new ContainerBuilder();
        builder.RegisterInstance(new Class(new SubClass())).AsSelf();
        var cont = builder.Build();
        new Registrations(cont).Items
            .Where(x => x.Key == typeof(Class))
            .SelectMany(x => x.Value)
            .ShouldEqualEnumerable(
                new Registration(typeof(Class), false));
    }

    [Fact]
    public void LambdaDoesNotNeedValidation()
    {
        var builder = new ContainerBuilder();
        builder.Register(_ => new Class(new SubClass())).AsSelf();
        var cont = builder.Build();
        new Registrations(cont).Items
            .Where(x => x.Key == typeof(Class))
            .SelectMany(x => x.Value)
            .ShouldEqualEnumerable(
                new Registration(typeof(Class), false));
    }

    class SubClass
    {
    }

    class Class
    {
        public Class(SubClass cl)
        {
                
        }
    }
}